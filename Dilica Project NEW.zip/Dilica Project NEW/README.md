# SkyHigh
Moderation and Utility Bot Using discord.js v13
- Created By Firez

## How To Install
- Install latest release and enter
```npm install``` in terminal
